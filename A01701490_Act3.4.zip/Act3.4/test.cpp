#include <iostream>
#include <string>
#include <fstream>

// Este es un comentario

const int STATE_A = 0;
const int STATE_B = 1;
const int STATE_C = 2;
const int STATE_D = 3;
const int STATE_E = 4;
const int STATE_F = 5;
const int STATE_G = 6;
const int STATE_H = 7;
const int STATE_I = 8;

#include "Comentario.hpp"
#include "Entero.hpp"
#include "Reales.hpp"
#include "Variable.hpp"

using namespace std;

int main(int argc, char* argv[]) {
	string input;
	cout << "Nombre del archivo: ";
	cin >> input;
}